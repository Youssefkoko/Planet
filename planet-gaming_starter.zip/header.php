<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Planet_Gaming
 */

?>
<!doctype html>
<html <?php language_attributes();?>>
<head>
	<meta charset="<?php bloginfo('charset');?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="profile" href="https://gmpg.org/xfn/11">

  <!--====FONT AWESOME ICONS=====-->
  <link rel="stylesheet" href="<?php bloginfo('template_url');?>/assets/css/fontawesome-5.7.1-web/css/all.min.css" />
  <!--====GOOGLE FONTS======-->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet" />
  <!--=================CAROUSEL HERE==============-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css" />
  <!--=========BOOTSTRAP CSS=======-->
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory');?>/assets/css/bootstrap.min.css" />


  <?php wp_head();?>
  <!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<body <?php body_class();?>>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e('Skip to content', 'planet-gaming');?></a>
	<!--===========HEADER===========-->
  <header class="site-header" role="banner">
    <div class="nav-wrapper">
      <!--======NAV BAR START HERE=======-->
      <nav class="navbar navbar-expand-lg navbar-light bg-light" role="navigation"><a class="navbar-brand" href="<?php the_permalink();?>"><img
            class="logo" src="<?php bloginfo('stylesheet_directory');?>/assets/img/logo-planetgaming.png" alt="Planet Gaming BV" /></a><button class="navbar-toggler custom-toggler navbar-right"
          type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
          aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
					<?php wp_nav_menu(array(

    'menu' => 'primary',
    "container_class" => "collapse  navbar-collapse",
    "theme_location" => "primary",
    'container_id' => 'navbarNav',
    "container" => "nav",

    "menu_class" => "nav navbar-nav navbar-right",
    "menu_id" => 'main-menu',
    "depth" => 2,
    // "fallback_cb" => "bs4Navwalker::fallback",
    // "walker" => new bs4Navwalker(),
));
?>
        <ul class="navbar-nav phone">
            <li class="nav-item ">
              <img alt="Planet Game Phone number" class="phone-pic" src="<?php bloginfo('stylesheet_directory');?>/assets/img/phone-pic.png" />
              <a class="p-2" href="#">
                <span class="dagEnNacht">
                  Dag en Nacht Bereikbar
                </span>
              </a>
              <br />
              <span class="phone-number">
                0172 24 28 37
              </span>
            </li>
          </ul>
      </nav>
      <!--====NAV BAR ENDS HERE=====-->
    </div>
  </header>

	<div id="content" class="site-content">
