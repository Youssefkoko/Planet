<?php
/*
Template Name : Onze Producten
 */
get_header();
$thumbnail_url = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
// Categorie
$categorie_image_1 = get_field('categorie_image_1');
$categorie_1 = get_field('categorie_1');
$categorie_image_2 = get_field('categorie_image_2');
$categorie_2 = get_field('categorie_2');
$categorie_image_3 = get_field('categorie_image_3');
$categorie_3 = get_field('categorie_3');
$categorie_image_4 = get_field('categorie_image_4');
$categorie_4 = get_field('categorie_4');
//
$title = get_field('title');
$onze_producten_content = get_field('onze_producten_content');
// Product List
$image_product = get_field('image_product');
$title_of_product = get_field('title_of_product');
$description_of_product = get_field('description_of_product');

$image_2_of_onze_producten = get_field('image_2_of_onze_producten');

// Contact Section
$contact_title = get_field('contact_title');
$contact_content = get_field('contact_content');
?>
<!--=========CONTENT SECTION==========-->
<section>
  <?php if (has_post_thumbnail()) { // check for image ?>
    <div class="content" style=" background-image: url('<?php echo $thumbnail_url; ?>');
                                background-attachment: scroll;
                                background-repeat: no-repeat;
                                background-position: 50% 50%;
                                background-size: 100% 100%;
                                width: 100%;
                                height: 451px;
                                box-sizing: border-box;">

    </div>

<?php } else {?>
    <div class="content" id="bg-image">

    </div>
<?php }?>

    <!-- ========= END OF CONTENT SECTION ======== -->
  </section>
  <section>
    <!-- ======= CATEGORY SECTION HERE ====== -->
    <div class="container text-capitalize " id="category">
      <div class="row">
        <div class="col-md-3 col-sm-6 mt-5">
          <img src="<?php echo $categorie_image_1['url']; ?>" alt="<?php echo $categorie_image_1['alt']; ?>">
          <h5 class="my-3"><?php echo $categorie_1; ?></h5>
        </div>
        <div class="col-md-3 col-sm-6 mt-5">
          <img src="<?php echo $categorie_image_2['url']; ?>" alt="<?php echo $categorie_image_1['alt']; ?>">
          <h5 class="my-3"><?php echo $categorie_2; ?></h5>
        </div>
        <div class="col-md-3 col-sm-6 mt-5">
          <img src="<?php echo $categorie_image_3['url']; ?>" alt="<?php echo $categorie_image_1['alt']; ?>">
          <h5 class="my-3"><?php echo $categorie_3; ?></h5>
        </div>
        <div class="col-md-3 col-sm-6 mt-5">
          <img src="<?php echo $categorie_image_3['url']; ?>" alt="<?php echo $categorie_image_1['alt']; ?>">
          <h5 class="my-3"><?php echo $categorie_4; ?></h5>
        </div>
      </div>
    </div>
    <h1 class="text-capitalize text-center mt-4 cate">categorie</h1>
    <!-- ========== END OF CATEGORY SECTION ====== -->
  </section>
  <section>
    <!-- ============ ONZE PRODUCTEN SECTION ======= -->
    <div class="container">
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8 onze-producten">
          <h1><?php echo $title; ?></h1>
          <p><?php echo $onze_producten_content; ?> </p>
        </div>
        <div class="col-md-2"></div>
      </div>
    </div>
  </section>
  <!-- ============ END ONZE PRODUCTEN SECTION ======= -->
  <!--=============PRODUCTE ITEMS START HERE=======-->
  <section>
    <div class="container product-lists">
      <!-- ====== FIRST ROW HERE ===== -->
      <div class="row">
      <?php
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$loop = new wp_Query(array(
    'posts_per_page' => 6,
    'paged' => $paged,
    'post_type' => 'onze_producten',
    'orderby' => 'rand',
    'order' => 'ASC',
));?>
    <?php while ($loop->have_posts()): $loop->the_post();?>
					<div class="col-lg-4">
						<div class="product-list">
							<?php if (has_post_thumbnail()) { // check for Image
        the_post_thumbnail();}?>
					    <h3 class="title"><?php the_title();?></h3>
							<p class="description"><?php the_content();?>
							</p><a href="<?php the_permalink();?>" class="btn btn-warning text-uppercase">bekijk meer</a>
						</div>
					</div>
				<?php endwhile;?>


      <!-- ======= END FIRST ROW ====== -->
      </div>
      <!-- ====== SECOND ROW HERE ======= -->
      <!-- ======= END SECOND ROW HERE======= -->
      <div class="center-pagination">
        <div class="pagination">
        <?php pagination_bar($loop);?>

        </div>
        <?php wp_reset_postdata();?>
      </div>
    </div>

    <!--==========END OF PRODUCT ITEMS HERE==========-->
  </section>

  <!--=============PLANET GAMING 2==========-->

  <?php if (has_post_thumbnail()) { // check for Image ?>
  <section>
      <div style="
                  background-image: url('<?php echo $image_2_of_onze_producten['url']; ?>');
                  background-attachment: scroll;
                  background-repeat: no-repeat;
                  background-position: 50% 50%;
                  background-size: 100% 100%;
                  width: 100%;
                  height: 396px;
                  box-sizing: border-box;"
                  class="planet-gaming-2-content text-center">
                  <div class="over-lay">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <p>Als <strong>Planet Gaming </strong><br />bieden wij <span class="content-text-bold">klant-
                  en spelersgericht kansspelen</span>voor in de Horeca. </p><a href="#" class="btn btn-light-2 text-uppercase">onze
                services</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php } else {?>
    <section>
      <div id="planet-gaming-3" class="planet-gaming-2-content text-center">
        <div class="over-lay">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <p>Als <strong>Planet Gaming </strong><br />bieden wij <span class="content-text-bold">klant-
                  en spelersgericht kansspelen</span>voor in de Horeca. </p><a href="#" class="btn btn-light-2 text-uppercase">onze
                services</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  <?php }?>


  <!--=============END OF PLANET GAMING 2==========-->
  <!--==============START CONTACT SECTION==========-->
  <section id="onze-producten-contact">
    <div class="container mt-5">
      <div class="row">
        <div class="col-lg-6">
          <!--===START CONTACT FORM====-->
          <div class=" contact-wrapper">
            <form>
              <h3 class="text-center ">Contact</h3>
              <div class="form-group"><label class="naam" for="name">Naam </label><input type="name" class="form-control"
                  id="inputName" aria- describedby="name" placeholder="Uw naam" /></div>
              <div class="form-group"><label class="emailadres" for="emailadres">Emailadres
                </label><input type="email" class="form-control" id="inputEmailAdres" placeholder="Uw emailadres" /></div>
              <div class="form-group"><label class="onderwerp" for="onderwerp">Onderwerp
                </label><input type="onderwerp" name="" class="form-control" id="inputonderwerp" placeholder="Uw onderwerp" /></div>
              <div class="form-group"><label class="bricht" for="text">Bericht </label><input type="text" name="text"
                  class="form-control" id="inputtext" placeholder="Uw bericht" /></div><button type="submit" class="btn btn-contact text-uppercase">verzenden
              </button>
            </form>
          </div>
          <!--====END OF CONTACT FORM====-->
          <!--=====END OF COLUNM 6 HERE====-->
        </div>
        <div class="col-lg-6 ">
          <div class="contact-wrapper-2">
            <h3><?php echo $contact_title ?> </h3>
            <p><?php echo $contact_content; ?></p><button type="button" class="btn btn-primary text-uppercase">meer
              informatie </button>
          </div>
          <!-- END OF COLLOMN-6 HERE -->
        </div>
      </div>
    </div>
    <!-- END OF THE CONTAINER HERE -->
  </section>
  <!--==============END CONTACT SECTION==========-->


