<?php
/**
 *
 *
 * @package Planet_Gaming
 */
$thumbnail_url = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
// Custom Fields
$elam_group = get_post_meta(get_the_ID(), 'elam_group', true);
$eurocoin_gaming = get_post_meta(get_the_ID(), 'eurocoin_gaming', true);
$eurocoin_interactive = get_post_meta(get_the_ID(), 'eurocoin_interactive', true);
// Advanced Custom Fields
$first_title = get_field('first_title');
$onzeProductenTitle = get_field('onze_producten_title');
$onzeProductenContent = get_field('onze_producten_content');
$image_of_product = get_field('image_of_product');
$product_title = get_field('product_title');
$product_description = get_field('product_description');
$image_of_product_2 = get_field('image_of_product_2');
$product_title_2 = get_field('product_title_2');
$product_description_2 = get_field('product_description_2');
$image_of_product_3 = get_field('image_of_product_3');
$product_title_3 = get_field('product_title_3');
$product_description_3 = get_field('product_description_3');
$image_of_product_4 = get_field('image_of_product_4');
$product_title_4 = get_field('product_title_4');
$product_description_4 = get_field('product_description_4');
$image_of_product_5 = get_field('image_of_product_5');
$product_title_5 = get_field('product_title_5');
$product_description_5 = get_field('product_description_5');
$image_of_product_6 = get_field('image_of_product_6');
$product_title_6 = get_field('product_title_6');
$product_description_6 = get_field('product_description_6');
$contact_description = get_field('contact_description');

get_header();
?>

<!--=========CONTENT SECTION==========-->
<section>
    <div class="content" id="bg-image">
      <div class="row">
        <div class="col-md-4 d-flex justify-content-start">
          <div class="content-text text-center">
            <p class="">
            Als
              <strong>
                Planet Gaming
              </strong>
              bieden wij
              <span class="content-text-bold">
                klant- en spelersgericht kansspelen
              </span>
              voor in de Horeca.
            </p>

            <a class="btn btn-light text-center text-uppercase" href="#">
              meer informatie
            </a>
          </div>
        </div>
        <div class=" col-md-8 offset-col-ms-8"></div>
      </div>
    </div>
    <!--=========END OF CONTENT SECTION========-->
  </section>
  <section>
    <!--=============ONZE PRODUCTEN SECTION==========-->
    <div class="container onze-producten-container">
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8 onze-producten">
          <h1>
            <?php echo $onzeProductenTitle; ?>
          </h1>
          <p>
          <?php echo $onzeProductenContent; ?>

          </p>
        </div>
        <div class="col-md-2"></div>
      </div>
    </div>
    <!--=============END ONZE PRODUCTEN SECTION==========-->
    <!--=============PRODUCTE ITEMS START HERE=======-->
    <!--=============PRODUCTE ITEMS START HERE=======-->
    <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="owl-carousel" id="product-slider">
        <?php $loop = new wp_Query(array(
    'post_type' => 'home_producten',
    'orderby' => 'ID',
    'order' => 'ASC',
));?>
          <?php while ($loop->have_posts()): $loop->the_post();?>
		          <div class="product">

		            <?php if (has_post_thumbnail()) {the_post_thumbnail();}?>
		            <h3 class="title"><?php the_title();?></h3>
		            <p class="description"><?php the_content();?></p>
		            <a class="btn btn-warning text-uppercase" href="<?php the_permalink();?>"> See More </a>
		            </div>
		            <?php endwhile;?>
        </div>
      </div>
    </div>
</div>
    <!--==========END OF PRODUCT ITEMS HERE==========-->
    <!--=============PLANET GAMING 2==========-->
    <section>
      <div class="planet-gaming-2-content text-center" id="planet-gaming-2">
        <div class="over-lay">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <p>
                  Als
                  <strong>
                    Planet Gaming
                  </strong>
                  <br />
                  bieden wij
                  <span class="content-text-bold">
                    klant- en spelersgericht kansspelen
                  </span>
                  voor in de Horeca.
                </p>
                <a class="btn btn-light-2 text-uppercase" href="#">
                  onze services
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--=============END OF PLANET GAMING 2==========-->
    <!--==============START CONTACT SECTION==========-->
    <section id="contact-section">
      <div class="container my-3">
        <div class="row">
          <div class="col-lg-6">
            <!--===START CONTACT FORM====-->
            <div class=" contact-wrapper">
              <form>
                <h3 class="text-center ">
                  Contact
                </h3>
                <div class="form-group">
                  <label class="naam" for="name">
                    Naam
                  </label>
                  <input aria-="" class="form-control" describedby="name" id="inputName" placeholder="Uw naam" type="name" />
                </div>
                <div class="form-group">
                  <label class="emailadres" for="emailadres">
                    Emailadres
                  </label>
                  <input class="form-control" id="inputEmailAdres" placeholder="Uw emailadres" type="email" />
                </div>
                <div class="form-group">
                  <label class="onderwerp" for="onderwerp">
                    Onderwerp
                  </label>
                  <input class="form-control" id="inputonderwerp" name="" placeholder="Uw onderwerp" type="onderwerp" />
                </div>
                <div class="form-group">
                  <label class="bricht" for="text">
                    Bericht
                  </label>
                  <input class="form-control" id="inputtext" name="text" placeholder="Uw bericht" type="text" />
                </div>
                <button class="btn btn-contact text-uppercase" type="submit">
                  verzenden
                </button>
              </form>
            </div>
            <!--====END OF CONTACT FORM====-->
            <!--=====END OF COLUNM 6 HERE====-->
          </div>
          <div class="col-lg-6 ">
            <div class="contact-wrapper-2">
              <h3>
                Wie is planet gaming
              </h3>
              <p>
                <?php echo $contact_description; ?>
              </p>
              <button class="btn btn-primary text-uppercase" type="button">
                meer informatie
              </button>
            </div>
            <!-- END OF COLLOMN-6 HERE -->
          </div>
        </div>
      </div>
      <!-- END OF THE CONTAINER HERE -->
    </section>
    <!--==============END CONTACT SECTION==========-->

<?php
get_footer();
?>