<?php
/*
Template Name Onze Services
 */

$title = get_field('title');
$onze_services_content = get_field('onze_services_content');
$contact_content = get_field('contact_content');
$stad = get_field('stad');
get_header();
?>

<section>
    <div class="content" id="bg-image">

    </div>
    <!-- ========= END OF CONTENT SECTION ======== -->
  </section>
  <section>
    <!--========= ONZE SERVICES SECTION ========-->

    <div class="container my-3" id="services-width">

      <h1 class="text-capitalize text-center"><?php echo $title; ?> </h1>
      <p> kwaliteit en continuïteit staan hierbij hoog in het vaandel, zowel voor onze producten en
        diensten als in samenwerking met onze klanten. Met oog voor ontwikkelingen en meer dan een halve eeuw ervaring
        richten wij ons op het amusement van morgen. Nieuwe technologieën, trends in de horeca en maatschappelijke
        veranderingen zijn continu ons uitgangspunt voor onze productrange. Zo introduceerden wij in samenwerking met
        Planet Gaming products als eerste een video terminal en video multi-gamer in de Nederlandse horeca.

        Expertise, innovatie en kwaliteit liggen aan de basis van onze producten. Trends, behoeftes en ontwikkelingen
        in
        de markt worden nauwgezet gevolgd en omgezet in creatieve spelconcepten. Dit resulteert in een breed spelaanbod
        in één bundel, wat u de mogelijkheid biedt een breed publiek te bereiken.
      </P>
      <a href="http://localhost/projects/wordpress-5.0.3/wordpress/contact/" class="btn btn-services  text-uppercase">contact</a>
      <!-- END OF THE CONTAINER HERE -->
    </div>

    <!--=============END ONZE SERVICES SECTION==========-->
  </section>
  <!-- ====== SERVICE ITEMS SECTION HERE =======  -->
  <section id="service-item">
    <!--=============ONZE PRODUCTEN SECTION==========-->
    <div class="container">
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8 onze-producten-services">
          <h1>Onze producten</h1>
          <p>Speelautomaat,
            gokkast of kansspelautomaat plaatsen? Wij adviseren met plezier wat de perfecte speelautomaat voor
            ú is en hoe deze zorgt voor meer opbrengst en meer endement. </p>
        </div>
        <div class="col-md-2"></div>
      </div>
    </div>
    <!--=============END ONZE PRODUCTEN SECTION==========-->
    <!--=============PRODUCTE ITEMS START HERE=======-->
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div id="product-slider" class="owl-carousel">
          <?php $loop = new wp_Query(array(
    'post_type' => 'home_producten',
    'orderby' => 'ID',
    'order' => 'ASC',
));?>
          <?php while ($loop->have_posts()): $loop->the_post();?>
						      <div class="product-item">
					        <?php if (has_post_thumbnail()) {the_post_thumbnail();}?>
								    <h3 class="title"><?php the_title();?> </h3>
								    <p class="description"><?php the_content();?> </p><a href="<?php the_permalink();?>" class="btn btn-warning text-uppercase">bekijk
								                meer</a>
								    </div>
								  <?php endwhile;?>
          </div>
        </div>
      </div>
    </div>
    <!-- ====== END SERVICE ITEMS SECTION HERE =======  -->
  </section>


  <!--==============START CONTACT SECTION==========-->
  <section id="services-contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <!--===START CONTACT FORM====-->
          <div class=" contact-wrapper">
            <form>
              <h3 class="text-center ">Contact</h3>
              <div class="form-group"><label class="naam" for="name">Naam </label><input type="name" class="form-control"
                  id="inputName" aria- describedby="name" placeholder="Uw naam" /></div>
              <div class="form-group"><label class="emailadres" for="emailadres">Emailadres
                </label><input type="email" class="form-control" id="inputEmailAdres" placeholder="Uw emailadres" /></div>
              <div class="form-group"><label class="onderwerp" for="onderwerp">Onderwerp
                </label><input type="onderwerp" name="" class="form-control" id="inputonderwerp" placeholder="Uw onderwerp" /></div>
              <div class="form-group"><label class="bricht" for="text">Bericht </label><input type="text" name="text"
                  class="form-control" id="inputtext" placeholder="Uw bericht" /></div><button type="submit" class="btn btn-contact text-uppercase">verzenden
              </button>
            </form>
          </div>
          <!--====END OF CONTACT FORM====-->
          <!--=====END OF COLUNM 6 HERE====-->
        </div>
        <div class="col-lg-6 ">
          <div class="contact-wrapper-2">
            <h3>Wie is planet gaming</h3>
            <p>NOVOMATIC Netherlands,
              met haar hoofdkantoor in Waalwijk,
              is in 2013 door het Oostenrijkse NOVOMATIC Group opgericht en bestaat uit een fusie
              van diverse Nederlandse bedrijven die actief zijn op verschillende terreinen in de
              kansspelindustrie. </p>
            <p>NOVOMATIC Netherlands kan worden onderverdeeld in twee business units,
              te weten 'Gaming Operations'en 'Gaming
              Technology'. De business unit 'Gaming Operations' is actief op
              het gebied van exploitatie van kansspelen in zowel horeca als speelautomatenhallen.
              De business unit 'Gaming Technology' omvat de ontwikkeling,
              productie en verkoop van kansspelen,
              online software ontwikkeling en systeem- en platformontwikkeling. </p><button type="button" class="btn btn-primary text-uppercase">meer
              informatie </button>
          </div>
          <!-- END OF COLLOMN-6 HERE -->
        </div>
      </div>
    </div>
    <!-- END OF THE CONTAINER HERE -->
  </section>
  <!--==============END CONTACT SECTION==========-->
  <?php get_footer();
?>